Lucky Draw Tamil Nadu — Website Prototype

Included:
- Responsive bilingual (Tamil/English) front-end
- Proposed prize plan display
- Registration form preview (does not save details)
- Admin dashboard preview and sample CSV export
- No payment integration, coupon issuance, OTP, backend, or winner selection

How to preview:
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox, or another browser.
3. Use the Tamil button in the top-right corner to switch languages.
4. Scroll to the Management dashboard and click Export demo report to test the sample CSV.

Important:
This is a static prototype, not a production website. It does not collect money or operate a draw.
Before any paid-entry prize scheme is advertised or launched, obtain qualified legal advice and confirm compliance with applicable Tamil Nadu law. A production deployment would also need secure hosting, backend/database, authentication, privacy protections, payment-provider approval if lawful, audit logs, and security testing.
